package com.vmware.numbergenerator.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "numbers-meta-data")
public class GeneratedNumbersData {

	@Id
	private String id;
	private Long goal;
	private Integer step;
	private GenerationStatus status;

	
	public GeneratedNumbersData() {
		super();
	}

	public GeneratedNumbersData(Long goal, Integer step) {
		this.goal = goal;
		this.step = step;
	}

	public GeneratedNumbersData(String id, Long goal, Integer step, GenerationStatus status) {
		this.goal = goal;
		this.step = step;
		this.id = id;
		this.status = status;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getGoal() {
		return goal;
	}

	public void setGoal(Long goal) {
		this.goal = goal;
	}

	public Integer getStep() {
		return step;
	}

	public void setStep(Integer step) {
		this.step = step;
	}

	public GenerationStatus getStatus() {
		return status;
	}

	public void setStatus(GenerationStatus status) {
		this.status = status;
	}

}
