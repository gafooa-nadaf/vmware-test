package com.vmware.numbergenerator.dao;

import com.vmware.numbergenerator.model.GeneratedNumbersData;

public interface NumberGeneratorDao {

	public GeneratedNumbersData upsertGeneratedNumbersMetadata(GeneratedNumbersData data);

	public GeneratedNumbersData getGeneratedMetaData(String id);

	public GeneratedNumbersData getGeneratedNumbersData(Long goal, Integer step);

}
