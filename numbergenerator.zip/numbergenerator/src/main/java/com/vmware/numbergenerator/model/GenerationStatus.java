package com.vmware.numbergenerator.model;

public enum GenerationStatus {
	IN_PROGRESS, SUCCESS, ERROR
}
