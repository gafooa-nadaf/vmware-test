package com.vmware.numbergenerator.service;

import com.vmware.numbergenerator.exception.InvalidNumberGenerationInput;
import com.vmware.numbergenerator.exception.NumberGenerationException;
import com.vmware.numbergenerator.model.GeneratedNumbersData;

public interface NumberGeneratorService {
	public String generateNumbers(Long goal, Integer step) throws InvalidNumberGenerationInput;

	public GeneratedNumbersData getGeneratedNumbersData(String id) throws NumberGenerationException;

	public String getGeneratedNumbers(String id) throws NumberGenerationException;
}
