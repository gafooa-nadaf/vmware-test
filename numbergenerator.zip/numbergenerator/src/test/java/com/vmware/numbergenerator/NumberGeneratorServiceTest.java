package com.vmware.numbergenerator;


import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.vmware.numbergenerator.dao.NumberGeneratorDao;
import com.vmware.numbergenerator.exception.InvalidNumberGenerationInput;
import com.vmware.numbergenerator.exception.NumberGenerationException;
import com.vmware.numbergenerator.model.GeneratedNumbersData;
import com.vmware.numbergenerator.model.GenerationStatus;
import com.vmware.numbergenerator.service.NumberGeneratorService;
import com.vmware.numbergenerator.service.impl.NumberGeneratorServiceImpl;
import com.vmware.numbergenerator.util.NumberGeneratorFileUtil;

@RunWith(MockitoJUnitRunner.class)
public class NumberGeneratorServiceTest {

	@InjectMocks
	NumberGeneratorService service = new NumberGeneratorServiceImpl();

	@Mock
	NumberGeneratorDao numberGeneratorDao;

	@Mock
	NumberGeneratorFileUtil fileUtil;

	@Test(expected = NumberGenerationException.class)
	public void generateNumbersInvalidInputTest() throws InvalidNumberGenerationInput {
		service.generateNumbers(100L, 1000);
	}
	
	@Test
	public void generateNumbersTest() throws InvalidNumberGenerationInput {
		GeneratedNumbersData data = new GeneratedNumbersData(100L, 2);
		data.setId("1111");
		data.setStatus(GenerationStatus.SUCCESS);
		Mockito.when(numberGeneratorDao.getGeneratedNumbersData(Mockito.anyLong(), Mockito.anyInt())).thenReturn(data);
		String id = service.generateNumbers(10000L, 1000);
		assertEquals("1111", id);
	}

}
