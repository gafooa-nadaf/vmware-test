package com.vmware.numbergenerator.dao.impl;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.vmware.numbergenerator.dao.NumberGeneratorDao;
import com.vmware.numbergenerator.model.GeneratedNumbersData;

@Component
public class NumberGeneratorDaoImpl implements NumberGeneratorDao {

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public GeneratedNumbersData upsertGeneratedNumbersMetadata(GeneratedNumbersData data) {
		GeneratedNumbersData savedData = null;
		if (!Objects.isNull(data)) {
			savedData = mongoTemplate.save(data);
		}
		return savedData;
	}

	@Override
	public GeneratedNumbersData getGeneratedMetaData(String id) {
		GeneratedNumbersData data = null;
		if (!StringUtils.isEmpty(id)) {
			data = mongoTemplate.findById(id, GeneratedNumbersData.class);
		}
		return data;
	}

	@Override
	public GeneratedNumbersData getGeneratedNumbersData(Long goal, Integer step) {
		GeneratedNumbersData data = null;
		if (goal > 0 && step > 0) {
			Query query = new Query(new Criteria().andOperator(Criteria.where("goal").is(goal), Criteria.where("step").is(step)));
			data = mongoTemplate.findOne(query, GeneratedNumbersData.class);
		}
		return data;
	}

}
