package com.vmware.numbergenerator.exception;

public class InvalidNumberGenerationInput extends NumberGenerationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3567629618933772418L;

	public InvalidNumberGenerationInput(String message) {
		super(message);
	}

}
