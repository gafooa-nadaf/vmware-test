package com.vmware.numbergenerator.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.StringUtils;

import com.vmware.numbergenerator.exception.InvalidNumberGenerationInput;

public class NumberGeneratorUtil {

	public static List<Long> generateNumbers(Long goal, Integer step) throws InvalidNumberGenerationInput {
		List<Long> numbers = new ArrayList<>();
		if (!StringUtils.isEmpty(NumberValidator.validateNumberGenerationInputs(goal, step))) {
			while (goal >= 0) {
				numbers.add(goal);
				goal -= step;
			}
		}
		return numbers;

	}
}
