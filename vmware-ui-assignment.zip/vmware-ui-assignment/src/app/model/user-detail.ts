export class UserDetail {  
    emailId : string;  
    name : string;  
    password : string ;  
}