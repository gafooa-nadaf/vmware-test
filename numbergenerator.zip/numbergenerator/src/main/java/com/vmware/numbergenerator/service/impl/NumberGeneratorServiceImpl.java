package com.vmware.numbergenerator.service.impl;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.vmware.numbergenerator.dao.NumberGeneratorDao;
import com.vmware.numbergenerator.exception.InvalidNumberGenerationInput;
import com.vmware.numbergenerator.exception.NumberGenerationException;
import com.vmware.numbergenerator.model.GeneratedNumbersData;
import com.vmware.numbergenerator.model.GenerationStatus;
import com.vmware.numbergenerator.service.NumberGeneratorService;
import com.vmware.numbergenerator.util.NumberGeneratorFileUtil;
import com.vmware.numbergenerator.util.NumberValidator;

@Component
public class NumberGeneratorServiceImpl implements NumberGeneratorService {

	@Autowired
	private NumberGeneratorDao numberGeneratorDao;

	@Autowired
	private NumberGeneratorFileUtil fileUtil;

	@Override
	public String generateNumbers(Long goal, Integer step) throws InvalidNumberGenerationInput {
		GeneratedNumbersData data = new GeneratedNumbersData(goal, step);
		if (NumberValidator.validateNumberGenerationInputs(goal, step)) {
			data = numberGeneratorDao.getGeneratedNumbersData(goal, step);
			if (Objects.nonNull(data) && data.getStatus().equals(GenerationStatus.SUCCESS)) {
				return data.getId();
			}
			data = new GeneratedNumbersData(goal, step);
			data.setStatus(GenerationStatus.IN_PROGRESS);
			data = numberGeneratorDao.upsertGeneratedNumbersMetadata(data);
			if (Objects.nonNull(data)) {
				fileUtil.generateNumbers(data.getId(), goal, step);
			}
		}
		return data.getId();
	}

	@Override
	public GeneratedNumbersData getGeneratedNumbersData(String id) throws NumberGenerationException {
		GeneratedNumbersData data = numberGeneratorDao.getGeneratedMetaData(id);
		if (Objects.isNull(data)) {
			throw new InvalidNumberGenerationInput("No task found with given Id");
		}
		return data;
	}

	@Override
	public String getGeneratedNumbers(String id) throws NumberGenerationException {
		if (StringUtils.isEmpty(id)) {
			throw new InvalidNumberGenerationInput("No task found with given Id");
		}
		return fileUtil.getGeneratedNumbers(id);
	}

}
