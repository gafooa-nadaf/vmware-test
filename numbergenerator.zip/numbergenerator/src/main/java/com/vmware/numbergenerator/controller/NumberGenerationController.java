package com.vmware.numbergenerator.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vmware.numbergenerator.constants.Constants;
import com.vmware.numbergenerator.exception.NumberGenerationException;
import com.vmware.numbergenerator.model.GeneratedNumbersData;
import com.vmware.numbergenerator.service.NumberGeneratorService;

/**
 * 
 * @author gafooa
 * APIs for Number Generation
 */

@RestController
@RequestMapping("/api")
public class NumberGenerationController {

	@Autowired
	private NumberGeneratorService service;

	/**
	 * Generates Numbers in decreasing order in steps and store in file
	 * @param data {goal - Starting Number from which sequence is generated, step - steps in sequence}
	 * @return UUID of the task
	 * @throws NumberGenerationException
	 */
	@PostMapping(path = "/generate", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Map<String, String>> generateNumbers(@RequestBody GeneratedNumbersData data)
			throws NumberGenerationException {

		String id = service.generateNumbers(data.getGoal(), data.getStep());
		Map<String, String> responseMap = new HashMap<>();
		responseMap.put(Constants.TASK_RESPONSE_KEY, id);
		ResponseEntity<Map<String, String>> response = new ResponseEntity<>(responseMap, HttpStatus.ACCEPTED);
		return response;

	}

	/**
	 * Gets Number generation task status by id
	 * @param id
	 * @return - status of generation task
	 * @throws NumberGenerationException
	 */
	@GetMapping(path = "/tasks/{id}/status", produces = "application/json")
	public ResponseEntity<Map<String, String>> getStatus(@PathVariable String id) throws NumberGenerationException {

		GeneratedNumbersData data = service.getGeneratedNumbersData(id);
		Map<String, String> responseMap = new HashMap<>();
		responseMap.put(Constants.RESULT_RESPONSE_KEY, data.getStatus().name());
		ResponseEntity<Map<String, String>> response = new ResponseEntity<>(responseMap, HttpStatus.OK);
		return response;
	}

	/**
	 * Gets the sequence of numbers generated based on task
	 * @param id
	 * @param action
	 * @return - Sequence of numbers generated
	 * @throws NumberGenerationException
	 */
	@GetMapping(path = "/tasks/{id}", produces = "application/json")
	public ResponseEntity<Map<String, String>> getGeneratedNumbers(@PathVariable String id,
			@RequestParam(required = true, defaultValue = Constants.API_ACTION_GET_NUM_LIST) String action)
			throws NumberGenerationException {
		Map<String, String> responseMap = new HashMap<>();
		ResponseEntity<Map<String, String>> response = null;
		if (action.equals(Constants.API_ACTION_GET_NUM_LIST)) {
			String numbersInTxt = service.getGeneratedNumbers(id);
			responseMap.put(Constants.RESULT_RESPONSE_KEY, numbersInTxt);
			response = new ResponseEntity<>(responseMap, HttpStatus.OK);
		} else {
			response = new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
		}
		
		return response;

	}
}
