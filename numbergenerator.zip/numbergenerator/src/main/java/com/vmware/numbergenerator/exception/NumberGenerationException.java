package com.vmware.numbergenerator.exception;

public class NumberGenerationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NumberGenerationException(String message) {
		super(message);
	}

}
