package com.vmware.numbergenerator.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.vmware.numbergenerator.dao.NumberGeneratorDao;
import com.vmware.numbergenerator.exception.InvalidNumberGenerationInput;
import com.vmware.numbergenerator.exception.NumberGenerationFileException;
import com.vmware.numbergenerator.model.GeneratedNumbersData;
import com.vmware.numbergenerator.model.GenerationStatus;

@Component
public class NumberGeneratorFileUtil {
	@Autowired
	private NumberGeneratorDao dao;

	@Async("numberGenTaskExecutor")
	public void generateNumbers(String id, Long goal, Integer step) {
		try {
			List<Long> numbers = NumberGeneratorUtil.generateNumbers(goal, step);
			if (!CollectionUtils.isEmpty(numbers)) {
				File file = new File(id+".txt");
				file.createNewFile();
				FileOutputStream fos = new FileOutputStream(file, true);
				fos.write(numbers.toString().getBytes());
				fos.close();
				GeneratedNumbersData data = new GeneratedNumbersData(id, goal, step, GenerationStatus.SUCCESS);
				dao.upsertGeneratedNumbersMetadata(data);
			}
		} catch (InvalidNumberGenerationInput | IOException e) {
			GeneratedNumbersData data = new GeneratedNumbersData(id, goal, step, GenerationStatus.ERROR);
			dao.upsertGeneratedNumbersMetadata(data);
		} catch (Exception e) {
			GeneratedNumbersData data = new GeneratedNumbersData(id, goal, step, GenerationStatus.ERROR);
			dao.upsertGeneratedNumbersMetadata(data);
		}
	}

	public String getGeneratedNumbers(String id) throws NumberGenerationFileException {
		StringBuilder builder = new StringBuilder();
		try {
			File file = new File(id+".txt");
			if (file.exists() && file.isFile()) {
				FileInputStream inputStream = new FileInputStream(file);
				int content;
				while ((content = inputStream.read()) != -1) {
					builder.append(((char) content));
				}
				inputStream.close();
			} else {
				throw new NumberGenerationFileException("Invalid task id");
			}

		} catch (IOException e) {
			throw new NumberGenerationFileException("Internal Error");
		}

		return builder.toString();
	}

}
