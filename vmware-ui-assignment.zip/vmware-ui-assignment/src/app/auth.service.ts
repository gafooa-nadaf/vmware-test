import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { UserDetail } from './model/user-detail';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private  baseUrl = "http://localhost:8080/api/";
  constructor(private http: Http, private router : Router) { }

  login(userDetail : UserDetail) : Observable<any>  
  {  
      let url = this.baseUrl + "login";  
      return this.http.post(url, userDetail);  
  }  
}
