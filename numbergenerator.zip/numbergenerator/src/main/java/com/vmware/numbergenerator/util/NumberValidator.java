package com.vmware.numbergenerator.util;

import com.vmware.numbergenerator.exception.InvalidNumberGenerationInput;

public class NumberValidator {

	public static boolean validateNumberGenerationInputs(Long goal, Integer step) throws InvalidNumberGenerationInput {
		if (goal <= 0 || step <= 0) {
			throw new InvalidNumberGenerationInput("Invalid Inputs. Goal and step should be positive numbers");
		} else if(step > goal) {
			throw new InvalidNumberGenerationInput("Invalid Inputs. Goal should be greater than Step");
		}
		return true;
	}
}
