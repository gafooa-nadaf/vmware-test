package com.vmware.numbergenerator.constants;

public interface Constants {

	String RESULT_RESPONSE_KEY = "result";
	String TASK_RESPONSE_KEY = "task";
	String EMPTY_STRING = "";
	String API_ACTION_GET_NUM_LIST = "get_numlist";
}
