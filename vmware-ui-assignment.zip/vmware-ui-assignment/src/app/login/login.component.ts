import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { AuthService } from '../auth.service';
import { UserDetail } from '../model/user-detail';  

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

    loginForm: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private authService: AuthService) {}
        private userDetail = new UserDetail();
    ngOnInit() {
        this.loginForm = this.formBuilder.group({
            email: ['', Validators.required, Validators.email],
            password: ['', Validators.required, Validators.minLength(6)]
        });
    }

    // convenience getter for easy access to form fields
    get f() { return this.loginForm.controls; }

    onSubmit() {
        this.submitted = true;
        console.log(this.f.email.value);
        // stop here if form is invalid
        if (this.loginForm.invalid) {
            return;
        }
        this.userDetail.emailId = this.f.email.value;  
        this.userDetail.password = this.f.password.value;  
        this.loading = true;
        this.authService.login(this.userDetail).subscribe(
            response =>{
                let result = response.json();
                if(result == true){
                    this.router.navigate(['/home', this.userDetail.name])
                } else {
                    alert("Email/Password is Invalid");
                }
            }
        )

        
    }

}
