package com.vmware.numbergenerator.exception;

public class NumberGenerationFileException extends NumberGenerationException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3567629618933772418L;

	public NumberGenerationFileException(String message) {
		super(message);
	}
}
