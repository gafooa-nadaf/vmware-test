Steps to run the App<br>
	1. Extract the contents from zip file(number-generator-app).<br>
	2. Inside Project directory, open command prompt and run build command to build the app - mvn clean insatll.<br>
	3. Target folder will be created in project directory with number-generator-app.jar.<br>
	4. Execute the command - java -jar number-generator-app.jar to run the application.<br>

Once the App is up and running,<br>
Browse the url - http://localhost:8090/swagger-ui.html, which shows the API contract and list of operations supported<br>